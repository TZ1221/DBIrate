/*
 * Retrieve all documents in sampleCollection with

 * limit on result set size using Java API
 * @file RetrieveAllDocumentsLimit.java
 */
import static com.mongodb.client.model.Filters.elemMatch;
import static com.mongodb.client.model.Filters.lt;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Filters.in;
import static com.mongodb.client.model.Filters.gte;
import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.text;
import static com.mongodb.client.model.Filters.ne;
import static com.mongodb.client.model.Filters.or;
import static com.mongodb.client.model.Filters.lte;


import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient; 
import com.mongodb.client.FindIterable; 
import com.mongodb.client.MongoCollection; 
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Indexes;
import com.mongodb.client.model.Projections;
import com.mongodb.client.model.TextSearchOptions;

import static com.mongodb.client.model.Projections.include;
import static com.mongodb.client.model.Projections.excludeId;

import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.json.JsonWriterSettings;

public class Assignment_7 { 
   
   public static void main( String args[] ) {  
      
      // Creating a Mongo client 
      MongoClient mongoClient = new MongoClient("localhost", 27017);
      System.out.println("Connected to the server successfully");  
      
      // Accessing the database 
      MongoDatabase database = mongoClient.getDatabase("restaurantDB");  
      System.out.printf("Database %s opened\n", database.getName());     

      // Retrieving a collection 
      MongoCollection<Document> collection = database.getCollection("restaurants");
      System.out.println("Collection sampleCollection selected successfully"); 

      
      
 
 
      Bson query =  lt("address.coord.0",-74)    ;
      FindIterable<Document> iterDoc = 
    		  collection.find( query).
    		  limit(5).
    		  projection(and(include("name", "address"), excludeId())).
    		  sort(new Document("address.coord.0", -1));
      JsonWriterSettings.Builder settingsBuilder = JsonWriterSettings.builder().indent(true);
      JsonWriterSettings settings = settingsBuilder.build();
      System.out.println("Find restaurants that are located west of longitude -74 degrees. Print documents for the first 5 that contain only the restaurant name and address fields, in descending order of longitude.:");
      for (Document doc : iterDoc) {   
         System.out.println(doc.toJson(settings));
      }
      
      
 
      collection.createIndex(Indexes.ascending("address.street", "name"));
      Bson query2 = and( text("\"Morris Park\"",new TextSearchOptions() )   )  ;
      FindIterable<Document> iterDoc2 = 
    		  collection.find( query2).
    		  limit(5).
    		  sort(new Document("address.zipcode", 1));
      JsonWriterSettings.Builder settingsBuilder2 = JsonWriterSettings.builder().indent(true);
      JsonWriterSettings settings2 = settingsBuilder2.build();
      System.out.println("Find restaurants that have\"Morris Park\" in both their name and their street name. Print documents for the first 5 in ascending order of zip code.");
      for (Document doc : iterDoc2) {   
         System.out.println(doc.toJson(settings2));
      }
      
      
      
      
      
      
      
    Bson query3 = and( ne("cuisine","American"),ne("borough","Brooklyn"), 
    		or( eq( "grades.0.grade","A"),
    				eq( "grades.1.grade","A"),
    				eq( "grades.2.grade","A"),
    				eq( "grades.3.grade","A"),
    				eq( "grades.4.grade","A")    )  
    		)    ;
    FindIterable<Document> iterDoc3 = 
  		  collection.find( query3).
  		  limit(5).
  		  sort(new Document("cuisine", 1));
    JsonWriterSettings.Builder settingsBuilder3 = JsonWriterSettings.builder().indent(true);
    JsonWriterSettings settings3 = settingsBuilder3.build();
    System.out.println("Find restaurants that do not prepare any 'American' cuisine, achieved at least one 'A' grade, and do not located in the borough of the Brooklyn. Print the first 5 documents, sorted in ascending order of cuisine:");
    for (Document doc : iterDoc3) {   
       System.out.println(doc.toJson(settings3));
    }
      
    
    
    
    
    Bson query4 = and (eq("borough","Bronx"),
    		or( lte( "grades.0.score",5),
    				lte( "grades.0.score",5),
    				lte( "grades.0.score",5),
    				lte( "grades.0.score",5),
    				lte( "grades.0.score",5)    ),
      		or( gte( "grades.0.score",10),
    				lte( "grades.0.score",10),
    				lte( "grades.0.score",10),
    				lte( "grades.0.score",10),
    				lte( "grades.0.score",10)    )
    		
    		);
    FindIterable<Document> iterDoc4 = 
  		  collection.find( query4).
  		  projection(and(include("name", "borough","grades"), excludeId())).
  		  sort(new Document("name", 1));
    JsonWriterSettings.Builder settingsBuilder4 = JsonWriterSettings.builder().indent(true);
    JsonWriterSettings settings4 = settingsBuilder4.build();
    System.out.println("Find restaurants that do not prepare any 'American' cuisine, achieved at least one 'A' grade, and do not located in the borough of the Brooklyn. Print the first 5 documents, sorted in ascending order of cuisine:");
    for (Document doc : iterDoc4) {   
       System.out.println(doc.toJson(settings4));
    }
      
      mongoClient.close();
   } 
}