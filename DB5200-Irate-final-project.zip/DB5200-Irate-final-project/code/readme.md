This is the main part of the project, the code itself.
