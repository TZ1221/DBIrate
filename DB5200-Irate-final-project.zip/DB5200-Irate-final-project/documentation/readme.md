This  folder contains the documentation for the project.
The documentatation  includes:
Project functionality
Project design.
Test plan
