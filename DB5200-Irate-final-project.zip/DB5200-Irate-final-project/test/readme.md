This test folder contains a Irate_test file which is used to test DB_Irate_final_124.
It is no different from the  Irate_test file under  DB_Irate_final_124.
