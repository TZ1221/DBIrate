# 5200 iRate Database Project



## Project Overview

This project is a portion of a an application that enables registered movie theater customers to rate a movie that they saw at the theater, and for other registered customers to vote for reviews.


### Team meber: 
* Zhengquan Chen (CCIS-ID :crdbuddy)
* Qi Xu          (CCIS-ID :zayccis)
### Technology that we used: 
* Java
* Derby



## Project Detail

### 1. Description
iRate is a social media application that encourages theater customers to rate a movie that they saw at the theater in the past week and write a short review. Other costumers can vote one review of a particular movie as "helpful" each day. The writer of the top rated review of a movie written three days earlier receives a free movie ticket, and voting is closed for all reviews of the movie written three days ago. Someone who voted one or more movie reviews as "helpful" on a given day will be chosen to receive a free concession item.

### 2. Database Schema
<img width="991" alt="diagram" src="https://media.github.ccs.neu.edu/user/5214/files/e2a3ad00-16c4-11ea-80e8-6ccb07e06939">

### 3. Design

#### Customer

This is a registered customer of the theater. The Customer information includes a customer name, email address, the date the customer joined, and a gensym customer ID. The information is entered by the theater when the customer registers. If a customer is deleted, all of his or her reviews and endorsements are deleted

1. customer_id (primary key): customer self-generated id as int, start with 1, increment by 1;
2. customer_Name: name of customers as varchar(64) and not null;
3. email: customer's email as varchar(64) and not null;
4. join_date: customer's registered as date and not null;

#### Movie

This is a record of a movie playing at the theater. It includes a title, and a gensym movie ID. This information is entered by the theater for each movie it plays.

1. movie_title: movie title as varchar and not null;
2. movie_id (primary key): self-generated identity of the movie as int, start with 1, increment by 1;

#### Review

This is a review of a particular movie attended by a custumer within the last week. The review includes the customer ID, the movie ID, the review date, a rating (0-5 stars), a short (1000 characters or less) review, and a gensym review ID. There can only be one movie review per customer, and the date of the review must be within 7 days of the most recent attendance of the movie. If a movie is deleted, all of its reviews are also deleted.

1. review_id (primary key): review self-generated id as int, start with 1, increment by 1;
2. customer_id: reference to customer_id in Customer table, If a customer is deleted, reviews and endorsement are also deleted;
3. movie_id: reference to movie_id in the Movie table. If a movie is deleted, reviews are also deleted;
4. review_date: review date as date and not null;
5. rating: rating (check between 0 and 5) as int and not null;
6. review: review varchar and not nulll;

#### Attendance

This is a record of a movie seen by a customer on a given date. It includes a movie ID, the attendance date, and the customer ID. This information is entered when the customer purchases a ticket for a show. If a movie is deleted, all of its attendances are deleted. Attendance info is used to verify attendance when creating a review.

1. movie_id: reference to movie_id in the Movie table;
2. customer_id: references to customer_id in the Customer table;
3. attendance_date: attended date; 

movie_id, customer_id, and attendance_date together becomes one primary keys.

#### Endorsement

This is an endoresement of a movie review by a customer. A customer's current endorsement of a review for a movie must be at least one day after the customer's endorsement of a review for the same movie. The endorsement includes the review ID, the customerID of the endorser, and the endoresemnt date. A customer cannot endorse his or her own review. If a review is deleted, all endorsements are also deleted.

1. review_id: reference to review_id in the review table;
2. customer_id: id of an endorsement;
3. endorse_date: endorsed date as date; 

review_id, endorse_id, and endorse_date together becomes one primary keys.


#### Triggers

1. review_limit_by_attendance: Customer has to attend to the movie before review it;

2. review_limit_by_date: Prevent review earlier than the attendance date;

3. review_limit_by_date2: Make sure review happens within 7 days of attendance;

4. endorse_limit_by_date: Prevent endorsement_date earlier than review date;

5. endorse_limit_by_customer: Prevent endorse their own review;

6. endorse_limit_by_oneDay: Make sure that customers can only endorse once everyday;


#### Functions

1. isEmail(): function of validating emails.

2. freeGift(): function of validating the customers for freeGift.

3. freeTicket(): function of validating customer of the top voted review written 3 days ago.




### 4. Setup

1) Look for the "paths" file in the repository and import it to Java project

2) Run the Irate_test.java with Junit testing / Java


### 5. Testing

Testing strategy
The Testing strategy is to use Junit to test the following things:

1. inserting data to tables

* if data can be inserted, if not, a message will pop out
cases included: rating INT NOT NULL, UNIQUE (movie_id, customer_id), etc.

ex: 

Gotcha, invalid input from customer.txt : [Fake, I am a Fake, 2013-11-01 21P01P20]

* if invalid email will be deleted:

ex: 

Fake,I am a Fake,2013-11-01 21P01P20 (invalid email)

* the size of inserted data: 

ex: 

Attendance size is 9 

Customer size is 10 

Movie size is 10 

Review size is 8 

Endorsement size is 8

2. Review constraints and triggers: invalid insertion will be deleted

* Test a customer can only have one review on one movie. 

ex: 

1004,10004,2019-01-23 11P11P11,3,CANT review it twice

* Test a customer can not review a movie if he/she did not watch that
 movie.
 
ex:

1010,10007,2019-01-22 11P11P11,0,I didn't see the movie

*Test insert review after 7 days reviews created. 

ex:

1009,10009,2019-06-30 11P11P11,2,More than 7 days

3. testEndorsementLimit: invalid insertion will be deleted

* Test a customer cannot endorse his/her own review. 

ex:

endorse: 100003,1004,2019-01-28 23P03P21
(review id : 100003)

review: 1004,10004,2019-01-22 11P11P11,3, too bad
(same Customer id 1004 )

* Test a customer can not endorse the review that is created 3 days ago. 

ex:

endorse:100002,1001,2018-12-04 23P03P22 

review: 1003,10003,2018-12-05 11P11P11,2,Class

* Test a customer can not endorse a review twice on the same day. 

ex:
100001,1001,2018-12-03 23P03P22 

100001,1001,2018-12-03 23P03P21

4. test Delete CASCADE

* If a customer is deleted, all of his or her attendances, reviews and endorsements are deleted.

* If a movie is deleted, all of its attendances and reviews are deleted. 

* If a review is deleted, all endorsements are also deleted.

5. test freeItem 6.1 no winner
ex: 
String date3="2015-01-31";

* winner
ex: String date2="2019-01-24";
6. test freeTicket

* no winner
ex: String date6="2019-2-26";

* winner
ex: String date4="2018-12-04";








